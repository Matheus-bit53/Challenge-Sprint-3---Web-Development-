INTEGRANTES:
- Bernardo de Paula Rodrigues — RM 572376
- Heitor Anacleto Araújo — RM 573599
- Henrique Nunes Mororó — RM 574073
- Isaac Israel Rosa Coimbra — RM 570072
- Matheus Henrique Pedersen Guerra — RM 571197




MANUAL DE INTERATIVIDADE (SPRINT 3)

A camada de dinamismo e interatividade do ScoutX foi construída utilizando JavaScript nativo (Vanilla JS) modularizado, organizado dentro do diretório assets/js/:

1. assets/js/ui.js
Responsável pelo gerenciamento de interface de usuário e feedback dinâmico. Contém a lógica para renderização de toasts e alertas visuais que informam o usuário sobre o status de suas ações na aplicação.

2. assets/js/feed.js
Controla o comportamento interativo das seções de Feed e Perfil:
- Contadores de Votos: Incremento dinâmico de votos em atributos de atletas sem recarregamento de página.
- Confirmação de Tags: Alternância de estado das tags de atributos.
- Ação de Seguir/Favoritar: Alternância de estado para seguir olheiros ou favoritar atletas.
- Filtros Dinâmicos: Filtragem em tempo real de cards por posição e região geográfica com manipulação direta do DOM.

3. assets/js/validation.js
Gerencia a validação de formulários de cadastro e login no front-end:
- Validação interativa de campos obrigatórios, formato de e-mail e tamanho de senha.
- Feedback de erros em tempo real com exibição de mensagens dinâmicas inline.

4. assets/js/main.js
Script de inicialização global que escuta o evento DOMContentLoaded e dispara a execução organizada de todos os módulos.