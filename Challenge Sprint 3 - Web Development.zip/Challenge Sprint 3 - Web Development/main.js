document.addEventListener('DOMContentLoaded', () => {
  if (typeof initFeed === 'function') initFeed();
  if (typeof initValidation === 'function') initValidation();
});