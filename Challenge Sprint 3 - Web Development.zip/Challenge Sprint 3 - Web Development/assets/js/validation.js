function initValidation() {
  const form = document.getElementById('login-form');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    let isValid = true;

    const email = document.getElementById('email');
    const password = document.getElementById('password');
    const errEmail = document.getElementById('error-email');
    const errPassword = document.getElementById('error-password');

   
    if (errEmail) errEmail.innerText = '';
    if (errPassword) errPassword.innerText = '';

  
    if (!email.value.includes('@') || email.value.trim() === '') {
      if (errEmail) errEmail.innerText = 'Insira um e-mail válido.';
      isValid = false;
    }

    if (password.value.length < 6) {
      if (errPassword) errPassword.innerText = 'A senha deve ter pelo menos 6 caracteres.';
      isValid = false;
    }

    if (isValid) {
      showToast('Login realizado com sucesso!', 'success');
      form.reset();
    } else {
      showToast('Corrija os erros no formulário.', 'error');
    }
  });
}