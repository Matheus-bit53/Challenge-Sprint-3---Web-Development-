
function initFeed() {
  const feed = document.getElementById('feed-container');
  const posFilter = document.getElementById('filter-position');
  const regFilter = document.getElementById('filter-region');

  
  if (feed) {
    feed.addEventListener('click', (e) => {
      
      if (e.target.closest('.btn-vote')) {
        const btn = e.target.closest('.btn-vote');
        let count = parseInt(btn.getAttribute('data-votes')) + 1;
        btn.setAttribute('data-votes', count);
        btn.querySelector('.vote-count').innerText = count;
        showToast('Voto computado com sucesso!', 'success');
      }

     
      if (e.target.classList.contains('btn-tag')) {
        const btn = e.target;
        const isConfirmed = btn.getAttribute('data-confirmed') === 'true';
        btn.setAttribute('data-confirmed', !isConfirmed);
        btn.classList.toggle('active');
        showToast(!isConfirmed ? 'Tag confirmada!' : 'Tag removida.', 'info');
      }

    
      if (e.target.classList.contains('btn-follow')) {
        const btn = e.target;
        btn.classList.toggle('following');
        const isFollowing = btn.classList.contains('following');
        btn.innerText = isFollowing ? 'Seguindo' : 'Seguir Olheiro';
        showToast(isFollowing ? 'Você começou a seguir este olheiro.' : 'Deixou de seguir.', 'info');
      }
    });
  }

 
  function applyFilters() {
    const selectedPos = posFilter ? posFilter.value : 'todos';
    const selectedReg = regFilter ? regFilter.value : 'todas';
    const cards = document.querySelectorAll('.athlete-card');

    cards.forEach(card => {
      const cardPos = card.getAttribute('data-position');
      const cardReg = card.getAttribute('data-region');

      const matchPos = selectedPos === 'todos' || cardPos === selectedPos;
      const matchReg = selectedReg === 'todas' || cardReg === selectedReg;

      card.style.display = (matchPos && matchReg) ? 'block' : 'none';
    });
  }

  if (posFilter) posFilter.addEventListener('change', applyFilters);
  if (regFilter) regFilter.addEventListener('change', applyFilters);
}